local anchor = mop.get_run_target()
if not anchor then
    error("Select a target before starting Swirling Vortex - Triple Ring.")
end
mop.set_anchor(anchor)

local slot = mop.get_slot()
local count = mop.get_count()
local tau = math.pi * 2

local function number_var(name, fallback, minimum, maximum)
    local value = mop.get_number(name, fallback)
    return math.max(minimum, math.min(maximum, value))
end

-- Divide the authoritative formation roster across three concentric rings.
-- Every ring travels at the same linear ground pace. Inner rings therefore
-- rotate faster than outer rings, allowing all characters to remain in walk
-- mode without one ring continually overtaking or falling behind its slots.
local ring_count = 3
local ring = slot % ring_count
local ring_slot = math.floor(slot / ring_count)
local members_in_ring = math.floor((count - 1 - ring) / ring_count) + 1
local phase = (ring_slot / math.max(1, members_in_ring)) * tau

local inner_radius = number_var("radius", 1.60, 1.10, 4.0)
local ring_spacing = number_var("spread", 0.75, 0.45, 2.0)
local ground_pace = number_var("pace", 2.70, 1.25, 3.4)
local staging_time = number_var("stage", 0.0, 0.0, 20.0)
local ramp_time = number_var("ramp", 1.0, 0.1, 10.0)
local radius = inner_radius + ring * ring_spacing
local angular_speed = ground_pace / radius
local lookahead = 0.14

local function rotation_at(t)
    local elapsed = math.max(0, t - staging_time)
    if elapsed < ramp_time then
        return angular_speed * elapsed * elapsed / (2 * ramp_time)
    end
    return angular_speed * (elapsed - ramp_time / 2)
end

local function position_at(t)
    local angle = phase + rotation_at(t)
    return radius * math.sin(angle), radius * math.cos(angle)
end

mop.log("triple-ring vortex started")
while mop.is_running() do
    local t = mop.time() + lookahead
    local x, z = position_at(t)
    local nx, nz = position_at(t + 0.04)
    local facing = math.atan(nx - x, nz - z)
    mop.trajectory_update(x, z, facing)
    mop.wait(1 / 30)
end
