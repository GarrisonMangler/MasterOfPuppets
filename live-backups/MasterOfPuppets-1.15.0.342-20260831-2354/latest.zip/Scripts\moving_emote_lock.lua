-- Reproduces the moving looping-emote state discovered while mirroring.
-- Start this synchronized script, broadcast a looping emote, then toggle the
-- initiator's weapon. Plugin-controlled movement can continue while the
-- followers retain the replayed animation.

local launch_anchor = mop.get_var("anchor") or ""
local explicit_target = mop.get_var("mop_run_target_explicit") == "true"
local target_name = explicit_target and launch_anchor or mop.get_run_target()
if not target_name or target_name == "" then
    error("Moving Emote Lock could not resolve the initiator or selected target")
end

local runtime_info = mop.runtime.info()
local conductor_name = runtime_info.conductor or ""
local local_character_name = runtime_info.character_name or ""

local function visible_target(name)
    local lookup = mop.actors.find(name)
    if lookup.status == "found" and lookup.actor and lookup.actor.is_loaded then
        return lookup.actor
    end
    return nil
end

local function reveal_explicit_target()
    if not explicit_target
        or conductor_name == ""
        or mop.names_match(local_character_name, conductor_name) then
        return
    end
    local assist_name = conductor_name:match("^(.-)@") or conductor_name
    mop.commands.execute('/assist "' .. assist_name .. '"', "local")
end

local function stable_target(name)
    local previous_id = nil
    local next_reveal = 0
    while mop.is_running() do
        local actor = visible_target(name)
        if actor and actor.entity_id and actor.entity_id > 0 then
            if previous_id == actor.entity_id then return actor end
            previous_id = actor.entity_id
        else
            previous_id = nil
            if mop.time() >= next_reveal then
                reveal_explicit_target()
                next_reveal = mop.time() + 1.0
            end
        end
        mop.wait(0.25)
    end
    return nil
end

local target = stable_target(target_name)
if not target then return end

local self = mop.self.snapshot()
local local_is_target = self and self.entity_id == target.entity_id
local target_weapon_drawn = target.is_weapon_drawn or false
local target_emote_id = target.emote_id or 0
local target_emote_looping = target.is_emote_looping or false
local last_looping_emote_id = target_emote_looping and target_emote_id or 0
local last_looping_emote_seen = target_emote_looping and mop.time() or -100

mop.log("Moving Emote Lock armed from " .. target_name
    .. "; perform a looping emote, then toggle the source weapon")

while mop.is_running() do
    target = visible_target(target_name)
    if not target then
        target = stable_target(target_name)
        if not target then return end
        self = mop.self.snapshot()
        local_is_target = self and self.entity_id == target.entity_id
        target_weapon_drawn = target.is_weapon_drawn or false
        target_emote_id = target.emote_id or 0
        target_emote_looping = target.is_emote_looping or false
    end

    local emote_id = target.emote_id or 0
    local emote_looping = target.is_emote_looping or false
    local weapon_drawn = target.is_weapon_drawn or false
    local weapon_transition = weapon_drawn ~= target_weapon_drawn

    if emote_looping and emote_id > 0 then
        last_looping_emote_id = emote_id
        last_looping_emote_seen = mop.time()
    end

    local emote_changed = emote_id > 0
        and (emote_id ~= target_emote_id
            or (emote_looping and not target_emote_looping))
    if emote_changed and not local_is_target then
        local mirrored = mop.actions.use("emote", emote_id, "local")
        if not mirrored.ok then
            mop.log("Unable to mirror emote " .. tostring(emote_id)
                .. ": " .. (mirrored.message or "unknown error"))
        end
    elseif not emote_looping
        and target_emote_looping
        and not weapon_transition
        and not local_is_target then
        local stopped = mop.actions.stop_emote()
        if not stopped.ok then
            mop.log("Unable to stop mirrored emote: " .. (stopped.message or "unknown error"))
        end
    end
    target_emote_id = emote_id
    target_emote_looping = emote_looping

    if weapon_transition then
        if not local_is_target then
            local weapon = mop.actions.weapon(weapon_drawn)
            if not weapon.ok then
                mop.log("Unable to mirror weapon transition: " .. (weapon.message or "unknown error"))
            elseif last_looping_emote_id > 0
                and mop.time() - last_looping_emote_seen <= 2.0 then
                mop.wait(0.15)
                local replay = mop.actions.use("emote", last_looping_emote_id, "local")
                if replay.ok then
                    mop.log("Locked emote " .. tostring(last_looping_emote_id)
                        .. " after weapon transition")
                else
                    mop.log("Unable to lock emote " .. tostring(last_looping_emote_id)
                        .. ": " .. (replay.message or "unknown error"))
                end
            end
        end
        target_weapon_drawn = weapon_drawn
    end

    mop.wait(0.10)
end
