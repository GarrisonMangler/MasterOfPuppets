local anchor = mop.get_run_target()
if not anchor then
    error("Select a target before starting Swirling Vortex.")
end
mop.set_anchor(anchor)

local tau = math.pi * 2
local roster = mop.visible_roster()
local slot = roster.slot or mop.get_slot()
local count = math.max(1, roster.count or mop.get_count())
if slot < 0 then
    slot = 0
end
if slot >= count then
    slot = slot % count
end

local function number_var(name, fallback, minimum, maximum)
    local value = mop.get_number(name, fallback)
    return math.max(minimum, math.min(maximum, value))
end

-- Freeze membership, spacing, gait, and radius at launch. Re-reading
-- visibility or walk state every tick mutates the circle.
local walking = mop.is_walking()
local requested_inner = number_var("inner", 1.50, 1.10, 2.80)
local requested_outer = number_var("outer", 2.80, 2.00, 4.00)
local min_spacing = number_var("spacing", 0.80, 0.50, 1.20)
local speed = number_var("speed", 1.00, 0.20, 2.00)
local staging_time = number_var("stage", 0.0, 0.0, 20.0)
local ramp_time = number_var("ramp", 1.0, 0.1, 10.0)
local inner = math.min(2.80, math.max(requested_inner, count * min_spacing / tau))
local outer = math.min(4.00, math.max(requested_outer, inner + 1.20))
local radius = walking and inner or outer
local omega = math.min(speed, 2.35 / inner)
local phase = (slot / count) * tau

local function rotation_at(t)
    local elapsed = math.max(0, t - staging_time)
    if elapsed < ramp_time then
        return omega * elapsed * elapsed / (2 * math.max(0.01, ramp_time))
    end
    return omega * (elapsed - ramp_time / 2)
end

mop.log(string.format(
    "swirling vortex frozen %s ring slot %d/%d r=%.2f",
    walking and "walk" or "run",
    slot,
    count,
    radius))

while mop.is_running() do
    local now = mop.time()
    local angle = phase + rotation_at(now)
    local next_angle = phase + rotation_at(now + 0.04)
    local x, z = radius * math.sin(angle), radius * math.cos(angle)
    local nx, nz = radius * math.sin(next_angle), radius * math.cos(next_angle)
    mop.trajectory_update(x, z, math.atan(nx - x, nz - z))
    mop.wait(1 / 30)
end
