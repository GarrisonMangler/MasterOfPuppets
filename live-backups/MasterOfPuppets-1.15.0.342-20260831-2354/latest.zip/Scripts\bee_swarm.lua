local anchor = mop.get_run_target()
if not anchor then
    error("Select a target before starting Bee Swarm.")
end
mop.set_anchor(anchor)

local slot = mop.get_slot()
local count = mop.get_count()
local seed = mop.get_seed()
local tau = math.pi * 2
local phase = (slot / math.max(1, count)) * tau
local band = slot % 3
local direction = (slot % 4 == 0) and -1 or 1

local function number_var(name, fallback, minimum, maximum)
    local value = mop.get_number(name, fallback)
    return math.max(minimum, math.min(maximum, value))
end

-- Compact defaults keep the target visibly at the center. These can be tuned
-- per launch with $radius, $spread, and $speed without editing the script.
local swarm_radius = number_var("radius", 1.45, 0.75, 5.0)
local band_spacing = number_var("spread", 0.38, 0.0, 1.5)
local speed_scale = number_var("speed", 1.0, 0.5, 2.0)
local base_radius = swarm_radius + band * band_spacing
local angular_speed = (0.72 + (slot % 5) * 0.055) * speed_scale
local lookahead = 0.24

local function position_at(t)
    local seeded_phase = phase + (seed % 97) * 0.001
    local angle = seeded_phase
        + direction * angular_speed * t
        + 0.22 * math.sin(t * 0.63 + phase * 1.7)

    -- Smooth radial breathing creates repeated spiral-in/spiral-out motion.
    local radius = base_radius
        + 0.24 * math.sin(t * 1.05 + phase * 1.9)
        + 0.10 * math.sin(t * 2.15 + phase * 0.7)

    -- Harmonics break the perfect carousel into lopsided arcs and soft loops.
    local x = radius * math.sin(angle)
        + 0.20 * math.sin(angle * 2 + phase)
    local z = radius * 0.82 * math.cos(angle)
        + 0.16 * math.sin(angle * 3 - phase * 0.5)
    return x, z
end

mop.log("bee swarm started")
while mop.is_running() do
    local t = mop.time()
    local x, z = position_at(t + lookahead)
    local nx, nz = position_at(t + lookahead + 0.04)
    local facing = math.atan(nx - x, nz - z)
    mop.trajectory_update(x, z, facing)
    mop.wait(1 / 30)
end
