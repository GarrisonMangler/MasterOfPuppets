-- A synchronized conversation for the eight members of Artemis Band and the
-- eight members of Kazuko Band. Every client runs the same timeline, but only
-- the named speaker sends each line.

local speaker = mop.get_name()
local reply_pause = 1.2
local reply_timeout = 20

local conversation = {
    { "Artemis Potato", "Before we perform, I want to ask something: what turns sixteen musicians into one band?" },
    { "Hermes Potato", "Listening. A melody travels farther when someone is ready to receive it." },
    { "Athena Potato", "Listening needs discipline. Without timing, even a good idea becomes noise." },
    { "Gaia Potato", "But silence matters too. Music needs open space in which it can breathe." },
    { "Nyx Potato", "And courage. Someone must play the first note before anyone knows where it leads." },
    { "Apollo Potato", "The first note offers direction, but it should never demand obedience." },
    { "Hephaestus Potato", "Then our work is like a forge: each sound changes the shape of the next." },
    { "Poseidon Potato", "And if one of us loses the rhythm, the others become the tide that carries them back." },
    { "Kazuko Aura", "That is a beautiful answer, but what happens when two bands hear the song differently?" },
    { "Barnabus Mangler", "We do not fight for the loudest version. We search for the truth shared by both." },
    { "Cassandra Mangler", "Sometimes that truth is uncomfortable. Harmony does not mean pretending we agree." },
    { "Ellis Mangler", "It means giving disagreement a rhythm, so it becomes a conversation instead of a wall." },
    { "Amelia Mangler", "Then every voice keeps its character, while still belonging to something larger." },
    { "Madeline Mangler", "Perhaps that is why an audience remembers feeling more clearly than perfection." },
    { "Sabrina Mangler", "Perfection ends with the final note. Meaning follows people home." },
    { "Martin Mangler", "So sixteen musicians become one band when each chooses to make the others worth hearing." },
    { "Artemis Potato", "Then let us not play merely at the same time." },
    { "Kazuko Aura", "Let us play with the same purpose." },
}

mop.log("sixteen voices started for " .. speaker)

local participating = false
for index = 1, #conversation do
    if speaker == conversation[index][1] then
        participating = true
        break
    end
end

if not participating then
    mop.log("sixteen voices skipped for non-cast character " .. speaker)
    return
end

for index = 1, #conversation do
    local line = conversation[index]
    if not mop.is_running() then
        break
    end

    if speaker == line[1] then
        mop.say(line[2])
    end

    -- Do not advance because a timer expired. Every client waits until the
    -- expected speaker's exact line is actually observed in /say chat.
    local heard = mop.wait_for_chat(line[1], line[2], reply_timeout)
    if not heard then
        mop.log("conversation stopped: timed out waiting for " .. line[1])
        return
    end

    mop.wait(reply_pause)
end

mop.log("sixteen voices finished for " .. speaker)
