-- Event-driven theatre example.
-- Optional variables:
--   $cue = exact text fragment to wait for (default: places everyone)
--   $macro = saved macro to run after the cue
--   $formation = saved formation to run before the macro

local cue = mop.get_var("cue") or "places everyone"
cue = string.lower(cue)
local deadline = mop.time() + 120

mop.log("Curtain Call is waiting for a /say cue containing: " .. cue)

while mop.is_running() and mop.time() < deadline do
    local remaining = math.max(0.05, deadline - mop.time())
    local event = mop.events.next("chat.message", remaining)
    if event.status == "timeout" then
        break
    end

    local text = string.lower(event.data.text or "")
    if string.find(text, cue, 1, true) then
        mop.log("Cue received from " .. (event.data.speaker or "unknown"))

        local formation = mop.get_var("formation")
        if formation and formation ~= "" then
            local launched = mop.formations.run(formation, "target", "precise", "current_pc")
            if not launched.ok then error(launched.message) end
            local arrived = mop.formations.await(60)
            if not arrived.ok then error(arrived.message) end
        end

        local macro = mop.get_var("macro")
        if macro and macro ~= "" then
            local launched = mop.macros.run(macro, {}, "local")
            if not launched.ok then error(launched.message) end
            local completed = mop.macros.await(60)
            if not completed.ok then error(completed.message) end
        end

        if mop.get_slot() == 0 then
            mop.say("The company is ready.")
        end
        return
    end
end

mop.log("Curtain Call ended without receiving its cue")
