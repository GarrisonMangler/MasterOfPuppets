-- A Lua-native conga for the Artemis and Kazuko bands. This script does not
-- execute macros or load saved formations. Select any visible actor as leader.

local spacing = 0.8
local me = mop.get_name()
local leader = mop.get_run_target()

if not leader then
    error("Select the conga leader before starting Dynamic Conga Line.")
end

local order = {
    "Artemis Potato",
    "Hermes Potato",
    "Athena Potato",
    "Gaia Potato",
    "Nyx Potato",
    "Apollo Potato",
    "Hephaestus Potato",
    "Poseidon Potato",
    "Kazuko Aura",
    "Barnabus Mangler",
    "Cassandra Mangler",
    "Ellis Mangler",
    "Amelia Mangler",
    "Madeline Mangler",
    "Sabrina Mangler",
    "Martin Mangler",
}

-- A roster member may also be selected as leader. Rotate the chain around that
-- member instead of creating two branches on opposite sides of the fixed list.
local leader_index = nil
for index = 1, #order do
    if mop.names_match(order[index], leader) then
        leader_index = index
        break
    end
end

local chain = {}
if leader_index then
    for step = 1, #order - 1 do
        local index = ((leader_index + step - 1) % #order) + 1
        chain[#chain + 1] = order[index]
    end
else
    for index = 1, #order do
        chain[#chain + 1] = order[index]
    end
end

if mop.names_match(me, leader) then
    mop.log(me .. " is leading the dynamic conga")
    return
end

-- Candidate anchors are ordered nearest predecessor first, then progressively
-- farther predecessors, ending with the selected leader. MoP continuously picks
-- the first visible candidate, so missing members are skipped and late arrivals
-- are inserted into the chain automatically.
local anchors = {}
local participating = false
for index = 1, #chain do
    if mop.names_match(chain[index], me) then
        participating = true
        for previous = index - 1, 1, -1 do
            anchors[#anchors + 1] = chain[previous]
        end
        anchors[#anchors + 1] = leader
        break
    end
end

if not participating then
    mop.log(me .. " is not part of Dynamic Conga Line")
    return
end

mop.follow_actor {
    anchors = anchors,
    offset_x = 0,
    offset_y = 0,
    offset_z = -spacing,
    face_anchor = true,
    facing_offset = 0,
    precision = 0.1,
    brake_at_position = true,
    pursuit_prediction = false,
    immediate_steering = true,
}

mop.log(me .. " joined the dynamic conga")
while mop.is_running() do
    mop.wait(0.1)
end
